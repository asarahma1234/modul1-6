module org.example.TugasModul6 {
    requires javafx.controls;
    requires javafx.fxml;

    opens tugasmodul6dahtu to javafx.fxml;
    exports tugasmodul6dahtu;
}
