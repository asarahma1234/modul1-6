package tugasmodul6dahtu.util;

public interface iMenu {
    void menu();
}
